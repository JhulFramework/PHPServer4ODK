<?php return
[
	'event'		=> '\\Jhul\\Components\\Event\\Event',
	'html'		=> '\\Jhul\\Components\\HTML\\HTML',
	'time'		=> '\\Jhul\\Components\\Time\\Time',
	'security'		=> '\\Jhul\\Components\\Security\\Security',
	'session'		=> '\\Jhul\\Components\\JHTTP\\Session\\Session',
	'xhelper'		=> '\\Jhul\\Components\\XHelper\\XHelper',
	'classmapper'	=> '\\Jhul\\Components\\ClassMapper\\ClassMapper',
	'router'		=> '\\Jhul\\Components\\Router\\Router',
	'database'		=> '\\Jhul\\Components\\Database\\Database',
];
