<?php return
[
	'package'	=> 'Jhul.Components.Lipi',

	'codes'	=>
	[
		'digital'	=> require( __DIR__.'/_digital_codes.php' ),
	],
];
