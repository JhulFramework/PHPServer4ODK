<?php return
[
	'class' => '\\Jhul\\Components\\Lipi\\Lipi',
];
