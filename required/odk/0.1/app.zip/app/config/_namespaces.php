<?php return
[
	'app' 	=> dirname(__DIR__),
 	'_modules'	=> dirname(__DIR__).'/modules'
];
