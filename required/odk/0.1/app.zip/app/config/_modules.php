<?php return
[
	'main' => '_modules\\main\\Module',
	'user' => '_modules\\user\\Module',
];
