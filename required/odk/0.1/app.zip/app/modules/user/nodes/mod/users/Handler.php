<?php namespace _modules\user\nodes\mod\users;

class Handler extends \Jhul\Core\Application\Node\Handler\_Class
{

	public function run()
	{
		
	}
}
