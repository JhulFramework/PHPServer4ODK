<?php return
[
      'definition'	=> 'L=6-30',
	'required'		=> TRUE,

	'validation_steps'	=> 'minLength:maxLength:type',
];
