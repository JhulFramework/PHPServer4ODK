<?php return
[
	'iname'	=>
	[
		'class'	=> '\\_modules\\user\\datatypes\\types\\IName',
		'config'	=> __DIR__.'/definitions/_iname',
	],

	'password' 	=>
	[
		'class'	=> '\\_modules\\user\\datatypes\\types\\Password',
		'config'	=> __DIR__.'/definitions/_password',
	],

	'xml'	=>  '\\_modules\\user\\datatypes\\types\\xml\\DataType',

];
