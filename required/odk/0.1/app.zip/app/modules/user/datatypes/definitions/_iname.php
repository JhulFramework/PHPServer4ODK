<?php return
[
      'definition'		=> 'L=3-15',

	'required'			=> TRUE,

	'validation_steps'	=> 'minLength:maxLength:type',
];
