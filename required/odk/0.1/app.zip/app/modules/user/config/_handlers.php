<?php return
[
	'login'	=> '_modules\\user\\nodes\\login\\Handler',
	'manage_forms'	=> '_modules\\user\\nodes\\mod\\forms\\Handler',
	'logout'	=> '_modules\\user\\nodes\\logout\\Handler',

];
