<?php return
[
	'login'				=> __DIR__.'/templates/login',

	'xform_list'			=> __DIR__.'/templates/xforms/list',

	'xform_upload'			=> __DIR__.'/templates/xforms/upload',

	'xform_confirm_deletion'	=> __DIR__.'/templates/xforms/confirm_deletion',
];
