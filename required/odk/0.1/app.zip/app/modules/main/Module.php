<?php namespace _modules\main;

class Module extends \Jhul\Core\Application\Module\_Class
{
	public function submitForm( $form )
	{
		
	}
}
