<?php return
[
	'index' 			=> '\\_modules\\main\\nodes\\pub\\index\\Handler',
	'form_list' 		=> '\\_modules\\main\\nodes\\pub\\form\\listing\\Handler',
	'form_submit'		=> '\\_modules\\main\\nodes\\pub\\form\\submit\\Handler',



	'data'			=> '\\_modules\\main\\nodes\\pub\\view_data\\Handler',


	'xform' 			=> '\\_modules\\main\\nodes\\pub\\xform\\Handler',


];
