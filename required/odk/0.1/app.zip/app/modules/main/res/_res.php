<?php return
[
	'templates' => __DIR__.'/webpage/_templates'
];
