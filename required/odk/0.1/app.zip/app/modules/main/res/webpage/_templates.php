<?php return
[
	'form_list'		=> __DIR__.'/templates/form_list',
	'view_data_list'	=> __DIR__.'/templates/view_data_list',
];
