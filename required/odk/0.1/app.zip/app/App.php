<?php namespace app;

class App extends \Jhul\Core\Application\Application
{
	
}
