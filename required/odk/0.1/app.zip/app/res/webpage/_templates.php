<?php return
[
	'layout' 	=> __DIR__.'/templates/layout/layout',

	'body'	=>
	[
		'f' => __DIR__.'/templates/layout/body',
		's'=>'main'
	],

	'show_form_data'	=> __DIR__.'/templates/show_form_data'
];
