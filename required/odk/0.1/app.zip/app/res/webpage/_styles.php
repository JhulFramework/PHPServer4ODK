<?php return
[
	'main' => __DIR__.'/templates/main', 
];
