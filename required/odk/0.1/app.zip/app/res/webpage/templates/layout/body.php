<?php require(__DIR__.'/header.php') ?>
<div class="container">
<div class="clear"></div>
<?= $content ; ?>
<div class="clear"></div>
</div>
<div class="footer" >
Powered By <a href="https://github.com/JhulFramework/Jhul" >JHUL FRAMEWORK</a>
</div>
