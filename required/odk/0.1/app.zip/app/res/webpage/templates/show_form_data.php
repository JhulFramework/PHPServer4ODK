<?php echo $data; ?>
