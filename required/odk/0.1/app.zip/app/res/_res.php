<?php return
[
	'templates' => __DIR__.'/webpage/_templates',
	'styles'	=> __DIR__.'/webpage/_styles',
];
