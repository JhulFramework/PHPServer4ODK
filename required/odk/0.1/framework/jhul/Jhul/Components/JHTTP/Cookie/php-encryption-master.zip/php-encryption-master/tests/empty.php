<?php
require_once \dirname(__DIR__).'/autoload.php';

$crypto_exception_handler_object_dont_touch_me = new \Defuse\Crypto\ExceptionHandler();
