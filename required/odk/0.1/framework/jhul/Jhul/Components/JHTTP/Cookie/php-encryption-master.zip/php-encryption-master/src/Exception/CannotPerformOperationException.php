<?php
namespace Defuse\Crypto\Exception;

class CannotPerformOperationException extends \Defuse\Crypto\Exception\CryptoException
{
    
}
